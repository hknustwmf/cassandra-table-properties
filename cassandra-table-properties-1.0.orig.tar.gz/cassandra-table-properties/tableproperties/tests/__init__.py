"""Unit test package"""

import os

TEST_ROOT = os.path.dirname(os.path.realpath(__file__))
