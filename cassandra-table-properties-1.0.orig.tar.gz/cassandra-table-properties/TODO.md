TODO
====

Warnings : dclocal_read_repair_chance table option has been deprecated and will be removed in version 4.0
